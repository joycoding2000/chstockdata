from chstockdata import daily
