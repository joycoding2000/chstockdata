import chstockdata
