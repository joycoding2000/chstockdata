# Historical opening execution evidence (R2.1)

`fetch_historical_opening_evidence(ticker, session_date, *, known_events=(),
tdx_reader=None, official_reader=None) -> FetchResult[dict]` is an additive
capability. The legacy `get_suspension_info`, `fetch_suspension_info`, and
`fetch_tradability` retain their existing behavior.

```python
from chstockdata import fetch_historical_opening_evidence

result = fetch_historical_opening_evidence("510300", "2026-09-11")
evidence = result.data
if evidence["opening_status"] == "OPEN_ACTIVITY_CONFIRMED":
    # The historical opening activity constraint is satisfied.
    # Prices and volumes in this evidence are not order fill inputs.
    pass
```

The supported security category scope is the four certified target ETFs
510300, 159915, 518880, 511010, two ETF halt controls 513100 and 159509, and
stock controls 688432 and 000002. This is a certification scope, not a
security/date verdict table. Other categories or source versions return
UNKNOWN. Only mootdx 0.11.7 / tdxpy 0.2.7 are certified for the current
transaction price boundary. They remain optional dependencies, loaded only
when this capability is invoked. `opening-pdf` is the optional pypdf extra
for essential official PDF bodies; the verified parser was pypdf 6.10.0.
An absent PDF parser produces an explicit `not_configured` attempt and
UNKNOWN execution evidence.

Every request targets Shanghai 09:30 and the half-open minute window
`[09:30,09:31)`, with an explicit session date and market. The policy version
is `R2.1`; the schema is `historical-opening-evidence/1`; the purpose is
`historical_opening_execution_constraint`. `retrieved_at` is an aware UTC
wall-clock observation. `information_available_at` remains null and
`information_basis` remains UNKNOWN because neither the historical TDX
result nor present official retrieval proves historical preopen availability.

`OPEN_ACTIVITY_CONFIRMED` requires genuine positive-volume 09:30 rows from
0x0fb5, validated prices and minute times, the certified 0x0fb4 crosscheck,
a successful current bounded official query with complete pagination and
interpretable returned events, and no known official block or conflicting
boundary. 09:25 auction activity, untimed minute points, and daily volume
cannot satisfy this rule. ETF transaction prices are divided by ten exactly
once in the new reader output boundary; stock prices are preserved. Original
parser price, normalized price, rule, unit, tick, category, versions, command,
request market/security/date, and observations are retained.

`BLOCKED_CONFIRMED` means a certified secondary-market interval blocks the
target instant. A resume during the minute does not cause a later retry.
A full-window official block with qualified positive activity is UNKNOWN
with `source_conflict=true` and `official_block_at_target=true`. A boundary
inside the minute that cannot be ordered against the HH:MM activity is
UNKNOWN. A later afternoon halt does not revoke an independently qualified
morning opening window. A missing or failed current essential official
query, partial page, wrong security, unknown event meaning/time, or malformed
essential attachment is UNKNOWN, including when a cached halt fact exists.

SSE uses the certified fund history or stock interval queries. Fund
`dateSource=2 / LSTP / stopTime=915` denotes 09:15–10:30 secondary trading
halt; certified SG/SH creation/redemption entries are distinguished. SSE
fund start/end dates must both be eight-digit valid dates equal to the current
requested session, including rows ignored as creation/redemption entries;
stale or cross-day rows cannot be interpreted using the single-session rule.
SSE
stock `endStopDate` is a last stop day and is never turned into midnight
resume. Only a compatible independently certified resume timestamp may
close that interval; a current later LAST_STOP_DAY cannot be erased by a
cached earlier resume. Stock start/end fields must be exactly eight ASCII
digits, represent valid calendar dates, and satisfy end >= start; a legal
continuous interval may start before the queried session. Resume compatibility
compares parsed dates, never raw strings or truncated fields.
SZSE uses the official fund announcement list and
essential official PDF bodies. Known periodic reports and other explicitly
nonsecondary titles are considered without creating a future-information
normality claim. Nonempty SZSE stock search bodies outside the current
certification scope fail closed; the known issuer halt facts still
participate.

`opening_known_events.json` contains narrow positive interval facts with
issuer/exchange identity, original source SHA, effective-time certification,
retrieval/cache provenance, and `offline_cache=true`. It is a packaged data
asset. It is not counted as a new live attachment retrieval and never replaces
the current bounded official query. The 000002 resume date has no authenticated
resume clock, so its interval end remains null. Callers may supply additional
`OfficialOpeningEvent` facts with provenance; wrong requested security/market
is an explicit structure failure, not a silently discarded necessary fact.

Metadata success describes source retrieval; it does **not** authorize
execution. Consumers must inspect `opening_status`, purpose, policy, session,
target/window, and evidence identity. Per-source `FetchAttempt` entries and
capability health use the existing observation plumbing, without a generic
router. The evidence hash binds the serialized evidence and observations.

The capability does not prove strict 09:30 fills, order queue position,
executable volume quota, all-day normality, complete historical PIT, or that
information was known at 09:15. The current query makes no global historical
absence/completeness claim; under R2.1, a legitimate empty current official
result can combine with certified opening activity and no known block.
