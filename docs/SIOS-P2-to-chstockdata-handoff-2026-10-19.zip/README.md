# SIOS P2 → chstockdata handoff packet (2026-10-19)

Status: DRAFT / awaiting Owner review; no engineering implementation or release authorized.

Read `00-consumer-request/SIOS-P2-chstockdata-consumer-data-request.md` first. The other four files are source evidence, not chstockdata engineering instructions.

Consumer requests bounded research data for RB, BU, C, CS, PP (2020 warmup; 2021–2025 exploration), not a new futures platform.

Chstockdata first performs read-only capability/source feasibility, then reports whether existing export, external vendor, or minimal CR is appropriate. Do not implement, purchase, push, or release automatically.

Review evidence is historical; data access and consumer qualification have not been established.

SHA256 (original included bytes):
- `00-consumer-request/SIOS-P2-chstockdata-consumer-data-request.md`: `5063c687cd4223366cc2dcaf4ea425b57046f185f1470e1e5ede5b496795097a`
- `01-evidence/R2-p2-directional-carry-minimal-falsification-design-2026-10-18.md`: `bf5ee4f5be19dbbf18411392be11e7656ce72f0078ebb06137d0a096c09bd0eb`
- `01-evidence/R2-p2-final-exploratory-feasibility-verdict-2026-10-18.md`: `c706ca2ba68cfa7875d92cc9db3a441bd9c8c75eb407121a7b4e4072716042f2`
- `01-evidence/R2-p2-first-exploratory-economic-falsification-2026-10-19.md`: `4b718773e93998580fe588507fcd6108575ebf47c966ce641dd5bf80537430a9`
- `01-evidence/attempt-01/run_status.json`: `35bc86cfdde8817a04b330a86bc0dae2d70fd402536f7c7e59db2ae25ba92c39`
